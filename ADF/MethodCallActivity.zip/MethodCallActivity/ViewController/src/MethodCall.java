
public class MethodCall {
    public MethodCall() {
    }

    public void onLoadMethod() {
        // Add event code here...
        String code= "HAPPY CODING";
    System.out.println("method invoked with code::"+ code);
    }
}
